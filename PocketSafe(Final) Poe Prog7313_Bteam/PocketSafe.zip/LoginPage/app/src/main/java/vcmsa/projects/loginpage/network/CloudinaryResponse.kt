package vcmsa.projects.loginpage.network

data class CloudinaryResponse(
    val secure_url: String
)
